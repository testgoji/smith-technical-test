const express = require('express');
const bodyParser= require('body-parser');
const app = express();
const MongoClient = require('mongodb').MongoClient;

app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.use(bodyParser.json());

MongoClient.connect('mongodb://AdamTheEconomistSmith:Milburg910@ds261838.mlab.com:61838/adamstododatabase', (err, client) => {
  if (err) return console.log(err);
  db = client.db('adamstododatabase');
  app.listen(3000, () => {
  	console.log('listening on 3000');
  });
})

app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static('public'))

app.get('/', (req, res) => {
  db.collection('items').find().toArray((err, result) => {
  	if (err) return console.log(err);
  	res.render('index', { items: result });
  });
});

app.post('/items', (req, res) => {
  db.collection('items').save(req.body, (err, result) => {
    if (err) return console.log(err);

    console.log('saved to database');
    res.redirect('/');
  });
});

app.put('/items', (req, res) => {
  console.log(req.body);
  db.collection('items')
  .findOneAndUpdate({name: req.body.name}, {
    $set: {
      name: req.body.name,
      item: req.body.item
    }
  }, {
    sort: {_id: -1},
    upsert: true
  }, (err, result) => {
    if (err) return res.send(err)
    res.send(result)
  })
});

app.delete('/items', (req, res) => {
  db.collection('items').findOneAndDelete({name: req.body.name},
  (err, result) => {
    if (err) return res.send(500, err)
    res.send({message: 'An item was deleted.' })
  });
})
